local delay = ...
local modem = peripheral.find("modem") or error("No modem attached", 0)
modem.open(15)
local event, side, channel, replyChannel, message, distance
repeat
event, side, channel, replyChannel, message, distance = os.pullEvent("modem_message") 
until message == "wave"
sleep(tonumber(delay))
while true do
    turtle.up()
    turtle.down()
end
