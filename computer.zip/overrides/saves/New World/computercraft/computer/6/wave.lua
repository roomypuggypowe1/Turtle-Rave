local modem = peripheral.find("modem") or error("No modem found")










modem.transmit(15, 15, "wave")
